package com.ichezzy.evolutionboost.boost;

public enum BoostType { SHINY, XP, EV, IV }
