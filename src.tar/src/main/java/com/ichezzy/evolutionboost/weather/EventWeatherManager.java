package com.ichezzy.evolutionboost.weather;

import com.ichezzy.evolutionboost.EvolutionBoost;
import com.ichezzy.evolutionboost.boost.BoostManager;
import com.ichezzy.evolutionboost.boost.BoostType;
import com.ichezzy.evolutionboost.configs.EvolutionBoostConfig;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;

public final class EventWeatherManager {

    private EventWeatherManager() {}

    /** Unsere Christmas-Dimension. */
    private static final ResourceKey<Level> CHRISTMAS_DIM =
            ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse("event:christmas"));

    /** Boost-Typen die vom Christmas-System betroffen sind. */
    private static final BoostType[] CHRISTMAS_BOOST_TYPES = { BoostType.SHINY, BoostType.XP, BoostType.IV };

    private enum StormState {
        IDLE,      // kein Sturm, Basis-Boosts aktiv
        PREPARE,   // „braut sich zusammen" (30 Sekunden)
        ACTIVE     // eigentlicher Sturm, erhöhte Boosts
    }

    private static StormState christmasState = StormState.IDLE;
    private static int christmasTicks = 0;
    private static int ticksSinceLastStorm = 0;
    private static boolean autoStormEnabled = false;
    private static boolean christmasBoostsInitialized = false;

    private static final int PREPARE_TICKS = 20 * 30;  // 30 Sekunden Vorwarnung
    private static final int EFFECT_INTERVAL = 20 * 2; // Alle 2 Sekunden Effekte

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(EventWeatherManager::tickServer);
        EvolutionBoost.LOGGER.info("[weather] EventWeatherManager initialized.");
    }

    /* =========================================================
       Public API – Commands
       ========================================================= */

    /** /eb weather christmas storm on - Startet sofort einen Sturm */
    public static void startChristmasStorm(MinecraftServer server) {
        if (server == null) return;

        ServerLevel level = getChristmasLevel(server);
        if (level == null) {
            EvolutionBoost.LOGGER.warn("[weather] Cannot start storm - event:christmas dimension not loaded!");
            return;
        }

        christmasState = StormState.PREPARE;
        christmasTicks = 0;

        broadcastToChristmas(server,
                Component.literal("❄ ").withStyle(ChatFormatting.WHITE)
                        .append(Component.literal("A fierce blizzard is brewing...").withStyle(ChatFormatting.AQUA))
        );

        EvolutionBoost.LOGGER.info("[weather] Christmas storm cycle STARTED (PREPARE).");
    }

    /** /eb weather christmas storm off - Stoppt den Sturm sofort */
    public static void stopChristmasStorm(MinecraftServer server) {
        if (server == null) return;

        // Zurück auf Basis-Boosts
        applyBaseBoosts(server);
        clearChristmasWeather(server);

        christmasState = StormState.IDLE;
        christmasTicks = 0;
        ticksSinceLastStorm = 0;

        broadcastToChristmas(server,
                Component.literal("☀ ").withStyle(ChatFormatting.YELLOW)
                        .append(Component.literal("The storm has cleared.").withStyle(ChatFormatting.GRAY))
        );

        EvolutionBoost.LOGGER.info("[weather] Christmas storm STOPPED (manual).");
    }

    /** /eb weather christmas auto on */
    public static void enableAutoStorm(MinecraftServer server) {
        autoStormEnabled = true;
        ticksSinceLastStorm = 0;

        // Basis-Boosts setzen wenn noch nicht geschehen
        ensureBaseBoosts(server);

        EvolutionBoostConfig cfg = EvolutionBoostConfig.get();

        broadcastToChristmas(server,
                Component.literal("⚙ ").withStyle(ChatFormatting.GOLD)
                        .append(Component.literal("Automatic blizzard cycle ENABLED (every " + cfg.christmasStormEveryMinutes + " min)")
                                .withStyle(ChatFormatting.AQUA))
        );

        EvolutionBoost.LOGGER.info("[weather] Auto storm cycle ENABLED.");
    }

    /** /eb weather christmas auto off */
    public static void disableAutoStorm(MinecraftServer server) {
        autoStormEnabled = false;

        broadcastToChristmas(server,
                Component.literal("⚙ ").withStyle(ChatFormatting.GOLD)
                        .append(Component.literal("Automatic blizzard cycle DISABLED").withStyle(ChatFormatting.GRAY))
        );

        EvolutionBoost.LOGGER.info("[weather] Auto storm cycle DISABLED.");
    }

    /** /eb weather christmas init - Setzt Basis-Boosts manuell */
    public static void initializeChristmasBoosts(MinecraftServer server) {
        applyBaseBoosts(server);

        EvolutionBoostConfig cfg = EvolutionBoostConfig.get();

        broadcastToChristmas(server,
                Component.literal("✨ ").withStyle(ChatFormatting.GOLD)
                        .append(Component.literal("Christmas boosts initialized: ALL x" + cfg.christmasBaseMultiplier)
                                .withStyle(ChatFormatting.GREEN))
        );
    }

    /** /eb weather christmas status */
    public static String getStatus() {
        EvolutionBoostConfig cfg = EvolutionBoostConfig.get();
        int stormDurationTicks = cfg.christmasStormDurationMinutes * 20 * 60;
        int intervalTicks = cfg.christmasStormEveryMinutes * 20 * 60;

        StringBuilder sb = new StringBuilder();
        sb.append("State: ").append(christmasState.name());

        if (christmasState == StormState.ACTIVE) {
            int remaining = stormDurationTicks - christmasTicks;
            sb.append(" (").append(formatTicks(remaining)).append(" remaining)");
            sb.append(" | Boosts: ALL x").append(cfg.christmasStormMultiplier);
        } else if (christmasState == StormState.PREPARE) {
            int remaining = PREPARE_TICKS - christmasTicks;
            sb.append(" (").append(formatTicks(remaining)).append(" until storm)");
        } else {
            sb.append(" | Boosts: ALL x").append(cfg.christmasBaseMultiplier);
            if (autoStormEnabled) {
                int remaining = intervalTicks - ticksSinceLastStorm;
                sb.append(" | Next storm in ").append(formatTicks(remaining));
            }
        }

        sb.append(" | Auto: ").append(autoStormEnabled ? "ON" : "OFF");

        return sb.toString();
    }

    public static boolean isStormActive() {
        return christmasState == StormState.ACTIVE;
    }

    /* =========================================================
       Tick-Logik
       ========================================================= */

    private static void tickServer(MinecraftServer server) {
        if (server == null) return;

        // Auto-Zyklus
        if (autoStormEnabled && christmasState == StormState.IDLE) {
            ticksSinceLastStorm++;

            EvolutionBoostConfig cfg = EvolutionBoostConfig.get();
            int intervalTicks = cfg.christmasStormEveryMinutes * 20 * 60;

            if (ticksSinceLastStorm >= intervalTicks) {
                startChristmasStorm(server);
                ticksSinceLastStorm = 0;
            }
        }

        if (christmasState == StormState.IDLE) return;

        christmasTicks++;

        switch (christmasState) {
            case PREPARE -> tickChristmasPrepare(server);
            case ACTIVE -> tickChristmasActive(server);
        }
    }

    private static void tickChristmasPrepare(MinecraftServer server) {
        int remaining = PREPARE_TICKS - christmasTicks;

        // Countdown-Nachrichten
        if (remaining == 20 * 20) {
            broadcastToChristmas(server,
                    Component.literal("❄ ").withStyle(ChatFormatting.WHITE)
                            .append(Component.literal("20 seconds until the blizzard hits!").withStyle(ChatFormatting.YELLOW))
            );
        } else if (remaining == 20 * 10) {
            broadcastToChristmas(server,
                    Component.literal("❄ ").withStyle(ChatFormatting.WHITE)
                            .append(Component.literal("10 seconds! Seek shelter!").withStyle(ChatFormatting.RED))
            );
        } else if (remaining == 20 * 5) {
            broadcastToChristmas(server,
                    Component.literal("❄ ").withStyle(ChatFormatting.WHITE)
                            .append(Component.literal("5...").withStyle(ChatFormatting.RED, ChatFormatting.BOLD))
            );
        }

        if (christmasTicks >= PREPARE_TICKS) {
            // Wechsel zu ACTIVE
            christmasState = StormState.ACTIVE;
            christmasTicks = 0;

            setChristmasWeather(server, true);
            applyStormBoosts(server);

            EvolutionBoostConfig cfg = EvolutionBoostConfig.get();

            broadcastToChristmas(server,
                    Component.literal("❄❄❄ ").withStyle(ChatFormatting.WHITE)
                            .append(Component.literal("A HOWLING BLIZZARD ENGULFS THE REALM!").withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD))
            );
            broadcastToChristmas(server,
                    Component.literal("   ✨ ALL BOOSTS now x").withStyle(ChatFormatting.GOLD)
                            .append(Component.literal(String.valueOf(cfg.christmasStormMultiplier)).withStyle(ChatFormatting.YELLOW, ChatFormatting.BOLD))
                            .append(Component.literal(" (Shiny, XP, IV)").withStyle(ChatFormatting.GRAY))
            );

            EvolutionBoost.LOGGER.info("[weather] Christmas storm ACTIVE. Storm boosts applied (ALL x{}).", cfg.christmasStormMultiplier);
        }
    }

    private static void tickChristmasActive(MinecraftServer server) {
        EvolutionBoostConfig cfg = EvolutionBoostConfig.get();
        int stormDurationTicks = cfg.christmasStormDurationMinutes * 20 * 60;

        // Effekte anwenden
        if (christmasTicks % EFFECT_INTERVAL == 0) {
            applyChristmasStormEffects(server);
        }

        // 1 Minute verbleibend
        int oneMinuteLeft = stormDurationTicks - (20 * 60);
        if (christmasTicks == oneMinuteLeft && oneMinuteLeft > 0) {
            broadcastToChristmas(server,
                    Component.literal("❄ ").withStyle(ChatFormatting.WHITE)
                            .append(Component.literal("The blizzard is beginning to calm down...").withStyle(ChatFormatting.AQUA))
            );
        }

        // Ende
        if (christmasTicks >= stormDurationTicks) {
            applyBaseBoosts(server);
            clearChristmasWeather(server);

            christmasState = StormState.IDLE;
            christmasTicks = 0;

            broadcastToChristmas(server,
                    Component.literal("☀ ").withStyle(ChatFormatting.YELLOW)
                            .append(Component.literal("The storm has faded. Peace returns to the realm.").withStyle(ChatFormatting.GRAY))
            );
            broadcastToChristmas(server,
                    Component.literal("   ✨ Boosts back to x").withStyle(ChatFormatting.GOLD)
                            .append(Component.literal(String.valueOf(cfg.christmasBaseMultiplier)).withStyle(ChatFormatting.GREEN))
            );

            EvolutionBoost.LOGGER.info("[weather] Christmas storm ended. Base boosts restored (ALL x{}).", cfg.christmasBaseMultiplier);
        }
    }

    /* =========================================================
       Boost-Management
       ========================================================= */

    /** Setzt alle Christmas-Boosts auf den Basis-Wert */
    private static void applyBaseBoosts(MinecraftServer server) {
        EvolutionBoostConfig cfg = EvolutionBoostConfig.get();
        double baseMult = cfg.christmasBaseMultiplier;

        BoostManager bm = BoostManager.get(server);

        for (BoostType type : CHRISTMAS_BOOST_TYPES) {
            bm.setDimensionMultiplier(type, CHRISTMAS_DIM, baseMult);
        }

        christmasBoostsInitialized = true;
        EvolutionBoost.LOGGER.info("[weather] Christmas BASE boosts applied: ALL x{}", baseMult);
    }

    /** Setzt alle Christmas-Boosts auf den Storm-Wert */
    private static void applyStormBoosts(MinecraftServer server) {
        EvolutionBoostConfig cfg = EvolutionBoostConfig.get();
        double stormMult = cfg.christmasStormMultiplier;

        BoostManager bm = BoostManager.get(server);

        for (BoostType type : CHRISTMAS_BOOST_TYPES) {
            bm.setDimensionMultiplier(type, CHRISTMAS_DIM, stormMult);
        }

        EvolutionBoost.LOGGER.info("[weather] Christmas STORM boosts applied: ALL x{}", stormMult);
    }

    /** Stellt sicher dass Basis-Boosts gesetzt sind */
    private static void ensureBaseBoosts(MinecraftServer server) {
        if (!christmasBoostsInitialized) {
            applyBaseBoosts(server);
        }
    }

    /* =========================================================
       Wetter setzen / löschen
       ========================================================= */

    private static ServerLevel getChristmasLevel(MinecraftServer server) {
        if (server == null) return null;
        return server.getLevel(CHRISTMAS_DIM);
    }

    private static void setChristmasWeather(MinecraftServer server, boolean thunder) {
        ServerLevel level = getChristmasLevel(server);
        if (level == null) {
            EvolutionBoost.LOGGER.warn("[weather] Christmas dimension not found.");
            return;
        }

        EvolutionBoostConfig cfg = EvolutionBoostConfig.get();
        int duration = (cfg.christmasStormDurationMinutes + 5) * 20 * 60;

        if (thunder) {
            level.setWeatherParameters(0, duration, true, true);
        } else {
            level.setWeatherParameters(duration, 0, false, false);
        }

        EvolutionBoost.LOGGER.info("[weather] Weather set: thunder={}", thunder);
    }

    private static void clearChristmasWeather(MinecraftServer server) {
        ServerLevel level = getChristmasLevel(server);
        if (level == null) return;

        level.setWeatherParameters(20 * 60 * 60, 0, false, false);

        // Spieler auftauen und Effekte entfernen
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (player.serverLevel() == level) {
                try {
                    player.setTicksFrozen(0);
                    player.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
                } catch (Throwable ignored) {}
            }
        }

        EvolutionBoost.LOGGER.info("[weather] Christmas weather cleared.");
    }

    /* =========================================================
       Storm-Effekte auf Spieler
       ========================================================= */

    private static void applyChristmasStormEffects(MinecraftServer server) {
        ServerLevel level = getChristmasLevel(server);
        if (level == null) return;

        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (player.serverLevel() != level) continue;

            BlockPos pos = player.blockPosition();
            boolean openSky = level.canSeeSky(pos);
            boolean nearHeat = isNearHeatSource(level, pos, 6);
            boolean isOverhang = !openSky && !isUnderRoof(level, pos); // Unter Überhang aber kein echtes Dach

            try {
                int current = player.getTicksFrozen();
                int required = player.getTicksRequiredToFreeze();

                if (openSky && !nearHeat) {
                    // Draußen unter freiem Himmel & keine Wärme -> SOFORT voll einfrieren
                    player.setTicksFrozen(required);

                    // Slowness II für 5 Sekunden
                    player.addEffect(new MobEffectInstance(
                            MobEffects.MOVEMENT_SLOWDOWN,
                            20 * 5, 1, false, true, true
                    ));

                    // Warnung
                    player.displayClientMessage(
                            Component.literal("❄ You're freezing! Find shelter or warmth!")
                                    .withStyle(ChatFormatting.AQUA),
                            true
                    );

                } else if (isOverhang && !nearHeat) {
                    // Unter Überhang (kein direkter Himmel, aber kein echtes Dach) -> langsamer einfrieren
                    int next = Math.min(required, current + 2);
                    player.setTicksFrozen(next);

                    // Leichtere Slowness
                    player.addEffect(new MobEffectInstance(
                            MobEffects.MOVEMENT_SLOWDOWN,
                            20 * 3, 0, false, true, true
                    ));

                } else if (nearHeat) {
                    // Bei Wärmequelle -> schnell auftauen
                    player.setTicksFrozen(Math.max(0, current - 10));
                    // Kein Slowness

                } else {
                    // Unter echtem Dach -> langsam auftauen
                    player.setTicksFrozen(Math.max(0, current - 4));
                }
            } catch (Throwable ignored) {}
        }
    }

    /**
     * Prüft ob der Spieler unter einem echten Dach ist (mindestens 2 Blöcke „massiv“ über ihm).
     */
    private static boolean isUnderRoof(ServerLevel level, BlockPos pos) {
        int solidCount = 0;
        BlockPos.MutableBlockPos check = new BlockPos.MutableBlockPos();

        // Prüfe die nächsten 10 Blöcke nach oben
        for (int y = 1; y <= 10; y++) {
            check.set(pos.getX(), pos.getY() + y, pos.getZ());
            if (!level.getBlockState(check).isAir()) {
                solidCount++;
                if (solidCount >= 2) {
                    return true; // Mindestens 2 solide Blöcke = echtes Dach
                }
            }
        }
        return false;
    }

    private static boolean isNearHeatSource(ServerLevel level, BlockPos center, int radius) {
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    cursor.set(center.getX() + dx, center.getY() + dy, center.getZ() + dz);
                    var state = level.getBlockState(cursor);

                    if (state.is(Blocks.CAMPFIRE) || state.is(Blocks.SOUL_CAMPFIRE)
                            || state.is(Blocks.FIRE) || state.is(Blocks.LAVA)
                            || state.is(Blocks.MAGMA_BLOCK) || state.is(Blocks.FURNACE)
                            || state.is(Blocks.BLAST_FURNACE) || state.is(Blocks.SMOKER)
                            || state.is(Blocks.TORCH) || state.is(Blocks.WALL_TORCH)
                            || state.is(Blocks.SOUL_TORCH) || state.is(Blocks.SOUL_WALL_TORCH)
                            || state.is(Blocks.LANTERN) || state.is(Blocks.SOUL_LANTERN)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /* =========================================================
       Helper
       ========================================================= */

    private static void broadcastToChristmas(MinecraftServer server, Component msg) {
        ServerLevel level = getChristmasLevel(server);
        if (level == null) return;

        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (player.serverLevel() == level) {
                player.sendSystemMessage(msg);
            }
        }
    }

    private static String formatTicks(int ticks) {
        int totalSeconds = Math.max(0, ticks / 20);
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        if (minutes > 0) {
            return minutes + "m " + seconds + "s";
        }
        return seconds + "s";
    }
}
